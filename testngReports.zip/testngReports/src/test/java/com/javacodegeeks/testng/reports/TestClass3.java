package com.javacodegeeks.testng.reports;

import org.testng.annotations.Test;

public class TestClass3 {

	@Test(groups="myGroup")
	public void d1() {
	}
	
	@Test
	public void d2() {
	}	
}
