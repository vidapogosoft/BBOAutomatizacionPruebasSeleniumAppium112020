# TestNGAllureReport
TestNGAllureReport
Article Link: https://www.swtestacademy.com/allure-testng/
